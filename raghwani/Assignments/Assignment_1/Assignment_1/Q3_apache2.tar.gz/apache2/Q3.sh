#!/usr/bin/bash 

#if test -f Stats.log
#then
#	rm Stats.log
#fi

cat *.log.* | awk -f Q2.awk
