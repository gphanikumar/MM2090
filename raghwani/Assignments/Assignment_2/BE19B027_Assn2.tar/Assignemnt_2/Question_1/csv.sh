#!/usr/bin/bash

if  test -f marks.csv 
then
	rm marks.csv
fi

quizDividor=$(( 32767 / 25 + 1))
endsemDividor=$(( 32767 / 50 + 1))

echo -e  "\"Sl.no\", \"Q1 (max 25)\", \"Q2 (max 25)\", \"Endsem (max 50)\"" >> marks.csv

for i in {1..50}
do
	echo "$i, $((( $RANDOM / $quizDividor ))), $((( $RANDOM / $quizDividor ))), $((( $RANDOM / $endsemDividor ) ))" >> marks.csv 
done


