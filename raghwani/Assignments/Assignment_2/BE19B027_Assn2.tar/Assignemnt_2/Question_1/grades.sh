#!/usr/bin/bash

cat marks.csv | awk '

BEGIN {
	FS=", "
	max=0
}

{
	if (NR == 1) {
		next
	}
	roll[NR] = $1
	q1[NR] = $2
	q2[NR] = $3
	endsem[NR] = $4
	total[NR]=($2 + $3 + $4)
	if (total[NR] > max) {
		max=total[NR]
	}
}

END {
	printf("%s \t %s \t %s \t %s \t %s \t %s \t %s \n", "Roll No.", "Q1(max 25)", "Q2(max 25)", "Endsem(max 50)", "Total", "Normalized Marks", "Grade")
	for (i=2; i<=NR; i++){
		normalizedMarks = ((total[i]/max)*100)
		if (normalizedMarks >= 90 ) {
			grade = "S"
		}	
		else if (normalizedMarks >= 80 ) {
			grade = "A"
		}	
		else if (normalizedMarks >= 70 ) {
			grade = "B"
		}	
		else if (normalizedMarks >= 60 ) {
			grade = "C"
		}	
		else if (normalizedMarks >= 50 ) {
			grade = "D"
		}	
		else if (normalizedMarks >= 40 ) {
			grade = "E"
		}	
		else if (normalizedMarks <= 40 ) {
			grade = "U"
		}	
		printf("%s \t \t %s \t \t %s \t \t %s \t \t \t %s \t \t %s \t \t %s \n",roll[i], q1[i], q2[i], endsem[i],  total[i], normalizedMarks, grade)
		
	}
}
'
