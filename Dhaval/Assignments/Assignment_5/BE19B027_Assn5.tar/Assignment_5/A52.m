


for x = 1:20
  for y = 1:20
   phi(x,y) = -2*x/(x.*x + y.*y);
   
  endfor
endfor
for x = 1:19
  for y = 1:19
    vx(x,y) = phi(x+1,y) - phi(x,y);
    vy(x,y) = phi(x,y+1) - phi(x,y);
    
  endfor
endfor

quiver(transpose(vx),transpose(vy),'r',1);