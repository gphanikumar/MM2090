% Assignment 5 
A = imread("dhaval.jpg");
B = im2double(A);
C = rot90(B);

D  = rgb2gray(C);

colormap('gray');

figure(1)

[a,b] = contour(D,6);

a(a<1) = NaN

figure(2)
plot(a(1,:), a(2,:))

xlim([0 2700])
ylim([0 2000])


