load("mydata.dat");
P
Q
S
X
