%%Ocatve

%% Run "pkg load image" in the command window before running this script!

%% Loading the image
img=imread('flower.png');
BW=im2bw(img);
binary=BW;
binary=imfill(binary,'holes');
binary=bwareaopen(binary,2000);


figure(1);


%% Visualizing the binary image
imshow(binary);
title('Binary Image')
boundary=bwboundaries(binary);

figure(2);
a=boundary{1,1};
plot(a(:,2),a(:,1));
title('Boundaries of the Binary Image')

grid
axis equal

figure(3);

X=a(:,2);
Y=a(:,1);
plot(X,Y);
title('Contour')
xlim([0 max(X)]);
ylim([0 max(Y)]);

%% Re-centering the contour
for i=1:length(X)
  X1(i)=X(i)-(sum(X)/length(X));
  Y1(i)=Y(i)-(sum(Y)/length(Y));
endfor

figure(4);
plot(X1,Y1);
title('Re-centered plot')


%% Conerting from cartesian to polar
for i=1:length(X)
  [T(i),R(i)]=cart2pol(X1(i),Y1(i));
endfor

figure(5);
polar(T,R);

A=polyfit(T,R,40);
W=polyval(A,T);


Z = linspace(1,length(R),length(R));
scatter(Z,R);
title('The number of peaks(n) in the scatter plot, [n-1]  defines the scale of symmetry in the flower!')
%% Calculating the symmetry in the flower
disp ("The number of peaks in the scatter plot defines the scale of symmetry in the flower!")



figure(6);
polar(T,W);
title('Plot of curve fitting on the contours obtained from the original image')


% Calculating the compression ratio
D = dir('flower.png');
B = whos('A');

Compression_Ratio = (D.bytes)./(B.bytes);

disp ("The compression ratio achieved is "), disp (Compression_Ratio)



