#!/usr/bin/bash

if test -f "rename.log"
then
	rm rename.log
fi

for file in $(find -type f ! -name "*.sh") 
do
	fullFileName=$(find $file -printf "%f")
	fileName=$(find $file -printf "%f" | cut -d "." -f 1)
	fileExtension=$(find $file -printf "%f" | cut -d "." -f 2)
	fileLoc=$(find $file -printf "%h")
	fileType=$(file -b --mime-type $file | cut -d "/" -f 2)

	if [[ $fileType == $fileExtension || $fileType == "x-ms-bmp" &&  $fileExtension == "bmp" ]]
	then
		echo "$file ==> File extension matches file type" >> rename.log
		echo "$file ==> File extension matches file type" 
		continue
	fi 

	if [ $fileType == "x-ms-bmp" ]
	then
		mv "$file" "$fileLoc/$fileName.bmp"
		echo "$file ==> $fileLoc/$fileName.bmp"	>> rename.log
		echo "$file ==> $fileLoc/$fileName.bmp" 
	else
		mv "$file" "$fileLoc/$fileName.$fileType"
		echo "$file ==> $fileLoc/$fileName.$fileType" >> rename.log
		echo "$file ==> $fileLoc/$fileName.$fileType"
	fi
done
